INSERT INTO public.address( address, address2, district, city_id, postal_code, phone, last_update)
	VALUES ('QAP1 Street','','West Coast-NL', '613', 'A2V 4M3', '709-999-9999', CURRENT_TIMESTAMP);