UPDATE public.customer
SET address_id = 621
WHERE last_name = 'QAP1';	