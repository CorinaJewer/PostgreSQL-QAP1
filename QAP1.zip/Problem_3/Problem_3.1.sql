INSERT INTO public.customer(store_id, first_name, last_name, email, address_id, activebool, create_date, last_update, active)
VALUES 
    (2, 'Alex', 'QAP1', 'alexqap1@gmail.com', 620, true, CURRENT_DATE, CURRENT_TIMESTAMP, 1),
    (2, 'Alice', 'QAP1', 'aliceqap1@gmail.com', 620, true, CURRENT_DATE, CURRENT_TIMESTAMP, 1),
    (2, 'Alexa', 'QAP1', 'alexaqap1@gmail.com', 620, true, CURRENT_DATE, CURRENT_TIMESTAMP, 1);
