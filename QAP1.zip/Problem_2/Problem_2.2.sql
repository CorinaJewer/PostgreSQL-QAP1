SELECT film_id, title, release_year, rental_rate
	FROM public.film
	WHERE rental_rate > 2;